ALTER TABLE "#__action_logs" ALTER COLUMN "log_date" DROP DEFAULT;
