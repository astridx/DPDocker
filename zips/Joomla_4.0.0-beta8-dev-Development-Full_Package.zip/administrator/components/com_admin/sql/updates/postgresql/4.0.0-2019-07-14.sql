ALTER TABLE "#__contact_details" DROP COLUMN "xreference";
ALTER TABLE "#__content" DROP COLUMN "xreference";
ALTER TABLE "#__newsfeeds" DROP COLUMN "xreference";