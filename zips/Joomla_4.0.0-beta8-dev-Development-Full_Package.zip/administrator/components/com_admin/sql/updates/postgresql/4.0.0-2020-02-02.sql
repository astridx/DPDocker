UPDATE "#__menu" SET "img" = 'class:bookmark' WHERE "path" = 'Banners';
UPDATE "#__menu" SET "img" = 'class:address-book' WHERE "path" = 'Contacts';
UPDATE "#__menu" SET "img" = 'class:rss' WHERE "path" = 'News Feeds';
UPDATE "#__menu" SET "img" = 'class:language' WHERE "path" = 'Multilingual Associations';
UPDATE "#__menu" SET "img" = 'class:search-plus' WHERE "path" = 'Smart Search';
