DELETE FROM "#__menu" WHERE "link" = 'index.php?option=com_csp' AND "menutype" = 'main';
