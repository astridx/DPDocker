UPDATE "#__menu" SET "link" = 'index.php?option=com_config&view=config' WHERE "link" = 'index.php?option=com_config&view=config&controller=config.display.config';
UPDATE "#__menu" SET "link" = 'index.php?option=com_config&view=templates' WHERE "link" = 'index.php?option=com_config&view=templates&controller=config.display.templates';
