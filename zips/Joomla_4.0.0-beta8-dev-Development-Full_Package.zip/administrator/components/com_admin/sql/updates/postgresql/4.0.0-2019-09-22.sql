ALTER TABLE "#__messages" ALTER COLUMN "date_time" DROP DEFAULT;
