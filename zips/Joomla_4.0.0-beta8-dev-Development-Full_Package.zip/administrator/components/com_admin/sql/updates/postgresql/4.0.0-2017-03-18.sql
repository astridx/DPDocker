ALTER TABLE "#__extensions" DROP COLUMN "system_data";
