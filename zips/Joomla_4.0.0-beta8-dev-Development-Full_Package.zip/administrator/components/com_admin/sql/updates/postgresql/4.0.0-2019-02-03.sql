DELETE FROM "#__menu" WHERE "link" = 'index.php?option=com_postinstall' AND "menutype" = 'main';
DELETE FROM "#__menu" WHERE "link" = 'index.php?option=com_redirect' AND "menutype" = 'main';
DELETE FROM "#__menu" WHERE "link" = 'index.php?option=com_joomlaupdate' AND "menutype" = 'main';
