ALTER TABLE "#__extensions" ADD COLUMN "note" character varying(255);
