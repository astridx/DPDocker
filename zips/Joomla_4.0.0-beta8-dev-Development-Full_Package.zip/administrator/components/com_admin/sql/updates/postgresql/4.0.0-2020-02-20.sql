ALTER TABLE "#__content_types" ALTER COLUMN "table" TYPE character varying(2048);
