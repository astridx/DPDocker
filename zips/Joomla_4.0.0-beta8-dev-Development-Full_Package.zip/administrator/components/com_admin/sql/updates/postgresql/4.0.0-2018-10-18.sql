UPDATE "#__content_types" SET "router" = '' WHERE "type_alias" = 'com_users.user';
