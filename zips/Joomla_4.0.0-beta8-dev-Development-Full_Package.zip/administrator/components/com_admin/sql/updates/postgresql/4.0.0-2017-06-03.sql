ALTER TABLE "#__extensions" ADD COLUMN "changelogurl" text;
ALTER TABLE "#__updates" ADD COLUMN "changelogurl" text;
