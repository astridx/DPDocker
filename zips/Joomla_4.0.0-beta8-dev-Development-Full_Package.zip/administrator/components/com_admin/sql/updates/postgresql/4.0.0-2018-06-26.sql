ALTER TABLE "#__user_notes" ALTER COLUMN "modified_user_id" SET DEFAULT 0;
