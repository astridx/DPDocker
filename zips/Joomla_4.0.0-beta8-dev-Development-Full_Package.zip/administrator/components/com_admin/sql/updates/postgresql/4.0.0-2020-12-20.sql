UPDATE "#__modules" SET "title" = 'Notifications' WHERE "#__modules"."id" = 9;
