UPDATE `#__menu` SET `link`='index.php?option=com_tags&view=tags' WHERE `menutype`='main' AND `path`='Tags';
UPDATE `#__menu` SET `link`='index.php?option=com_associations&view=associations' WHERE `menutype`='main' AND `path`='Multilingual Associations';
