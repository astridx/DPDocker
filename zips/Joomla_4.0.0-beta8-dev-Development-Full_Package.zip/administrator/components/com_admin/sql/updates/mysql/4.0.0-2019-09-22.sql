ALTER TABLE `#__messages` MODIFY `date_time` datetime NOT NULL;
