DELETE FROM `#__extensions` WHERE `type` = 'plugin' AND `element` = 'p3p' AND `folder` = 'system';
