UPDATE `#__extensions` SET `client_id` = 1 WHERE `name` = 'com_mailto';
UPDATE `#__extensions` SET `client_id` = 1 WHERE `name` = 'com_wrapper';
