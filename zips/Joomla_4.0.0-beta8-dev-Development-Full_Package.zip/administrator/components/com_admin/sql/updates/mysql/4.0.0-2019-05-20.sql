ALTER TABLE `#__extensions` ADD COLUMN `note` varchar(255) AFTER `state`;
