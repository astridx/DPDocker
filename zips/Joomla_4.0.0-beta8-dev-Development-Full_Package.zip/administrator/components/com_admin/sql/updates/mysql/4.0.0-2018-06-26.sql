ALTER TABLE `#__user_notes` CHANGE `modified_user_id` `modified_user_id` int(10) unsigned NOT NULL DEFAULT 0;
