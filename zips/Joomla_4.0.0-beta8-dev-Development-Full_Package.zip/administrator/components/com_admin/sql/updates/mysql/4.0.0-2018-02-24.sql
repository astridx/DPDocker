DELETE FROM `#__extensions` WHERE `type` = 'library' AND `element` = 'idna_convert';
