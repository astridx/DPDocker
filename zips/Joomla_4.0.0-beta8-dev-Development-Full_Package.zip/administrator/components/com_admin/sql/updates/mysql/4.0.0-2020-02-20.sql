ALTER TABLE `#__content_types` MODIFY `table` varchar(2048) NOT NULL DEFAULT '';
