ALTER TABLE `#__content_frontpage` ADD COLUMN `featured_up` datetime;
ALTER TABLE `#__content_frontpage` ADD COLUMN `featured_down` datetime;
