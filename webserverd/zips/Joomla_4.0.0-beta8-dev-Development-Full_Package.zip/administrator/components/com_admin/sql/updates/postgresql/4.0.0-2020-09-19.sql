UPDATE "#__menu" SET "link"='index.php?option=com_finder' WHERE "menutype"='main' AND "title"='com_finder' AND "link"='index.php?option=com_finder&view=index';
