INSERT INTO `#__extensions` (`package_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(0, 'plg_extension_namespacemap', 'plugin', 'namespacemap', 'extension', 0, 0, 1, 1, '', '', '', 0, '0000-00-00 00:00:00', 0, 0);
