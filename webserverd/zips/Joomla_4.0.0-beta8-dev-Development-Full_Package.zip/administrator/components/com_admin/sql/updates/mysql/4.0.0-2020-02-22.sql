DELETE FROM `#__extensions` WHERE `name` = 'com_mailto';
