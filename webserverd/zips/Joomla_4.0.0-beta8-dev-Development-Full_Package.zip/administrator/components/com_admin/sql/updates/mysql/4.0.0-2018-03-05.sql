ALTER TABLE `#__modules` CHANGE `content` `content` TEXT NULL;
