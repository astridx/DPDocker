DELETE FROM "#__extensions" WHERE "type" = 'library' AND "element" = 'phputf8';
