ALTER TABLE `#__action_logs` MODIFY `log_date` datetime NOT NULL;
